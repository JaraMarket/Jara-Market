<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Management</title>
    <!-- Include any CSS or JS libraries here -->
</head>

<body>
    <h1>Food Management</h1>
    <div id="food-management-app">
        <!-- Vue.js or React component will be mounted here -->
    </div>
    <!-- Include Vue.js or React and your compiled app.js -->
    <script src="{{ mix('js/app.js') }}"></script>
</body>

</html>
