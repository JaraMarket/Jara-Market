<h3>Login OTP</h3>

<h4>Hello, {{ $firstname }}</h4>
<p>Your OTP for Login process is: <strong>{{ $otp }}</strong></p>
<p>Please do not share this OTP with anyone.</p>

<p>Thanks</p>
<p>{{ Config('app.name') }} Team. </p>
