<h3>Registration OTP</h3>

<h4>Hello, {{ $firstname }}</h4>
<p>Your OTP for Registration is: <strong>{{ $otp }}</strong></p>
<p>Please do not share this OTP with anyone.</p>

<p>Thanks</p>
<p>{{ Config('app.name') }} Team. </p>
