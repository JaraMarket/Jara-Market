
<h3>Customer Registered Successfully</h3>

<p>Dear {{ $UserData->firstname }},</p>

<p>Thank you for registering with us. Your account has been created successfully.</p>

<p>Please keep your password Safe.</p>

Best regards,
<p>{{ config('app.name') }}</p>
