// import Vue from "vue";
// import SettingsManagement from "./components/SettingsManagement.vue";
// import ReportGeneration from "./components/ReportGeneration.vue";
// import CategoryManagement from "./components/CategoryManagement.vue";
// import FoodManagement from "./components/FoodManagement.vue";
// import OrderManagement from "./components/OrderManagement.vue";
// import UserManagement from "./components/UserManagement.vue";

// new Vue({
//     el: "#settings-management-app",
//     components: { SettingsManagement },
// });

// new Vue({
//     el: "#report-generation-app",
//     components: { ReportGeneration },
// });

// new Vue({
//     el: "#category-management-app",
//     components: { CategoryManagement },
// });

// new Vue({
//     el: "#food-management-app",
//     components: { FoodManagement },
// });

// new Vue({
//     el: "#order-management-app",
//     components: { OrderManagement },
// });

// new Vue({
//     el: "#user-management-app",
//     components: { UserManagement },
// });
