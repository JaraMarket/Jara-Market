<?php

namespace App\Http\Controllers;

use App\Models\StateRepresentative;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class StateRepresentativeController extends Controller
{
    public function index()
    {
        $representatives = StateRepresentative::with('user')->latest()->paginate(10);
        return view('representatives.index', compact('representatives'));
    }

    public function create()
    {
        $users = User::get();
        return view('representatives.create', compact('users'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'unique:state_representatives'],
            'phone' => ['required', 'string', 'max:20'],
            'state' => ['required', 'string', 'max:255'],
            'lga' => ['required', 'string', 'max:255'],
            'address' => ['required', 'string'],
        ]);

        // Create a new user with STATE_REPRESENTATIVE role
        $user = User::create([
            'name' => $validated['name'],
            'email' => $validated['email'],
            'password' => Hash::make(Str::random(12)), // Generate a random password
            'role' => 'STATE_REPRESENTATIVE'
        ]);

        // Create the state representative
        $representative = StateRepresentative::create($validated);

        return redirect()->route('representatives.index')
            ->with('success', 'State Representative created successfully');
    }

    public function edit(StateRepresentative $representative)
    {
        $users = User::where('is_active', true)->get();
        return view('representatives.edit', compact('representative', 'users'));
    }

    public function update(Request $request, StateRepresentative $representative)
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'email', 'unique:state_representatives,email,' . $representative->id],
            'phone' => ['required', 'string', 'max:20'],
            'state' => ['required', 'string', 'max:255'],
            'lga' => ['required', 'string', 'max:255'],
            'address' => ['required', 'string'],
        ]);

        // Update the associated user
        $user = User::where('email', $representative->email)->first();
        if ($user) {
            $user->update([
                'name' => $validated['name'],
                'email' => $validated['email']
            ]);
        }

        $representative->update($validated);

        return redirect()->route('representatives.index')
            ->with('success', 'State Representative updated successfully');
    }

    public function destroy(StateRepresentative $representative)
    {
        $representative->delete();
        return redirect()->route('representatives.index')
            ->with('success', 'State Representative deleted successfully');
    }

    public function toggleStatus(StateRepresentative $representative)
    {
        $representative->is_active = !$representative->is_active;
        $representative->save();

        return redirect()->route('representatives.index')
            ->with('success', 'Representative status updated successfully');
    }
}
