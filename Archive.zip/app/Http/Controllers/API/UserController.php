<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\UserSignupRequest;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use App\Mail\UserRegistered;
use Illuminate\Support\Facades\Mail;
use App\Mail\UserRegisteredOtp;
use App\Http\Requests\RegisterOTPRequest;
use App\Http\Requests\UserLoginRequest;
use App\Mail\UserLoginOtp;
use Illuminate\Support\Facades\Cache;
use App\Models\User_otp;
use App\Models\Wallet;

/**
 * @OA\Info(title="JaraMarket API", version="1.0")
 * @OA\Server(url="http://localhost:8000")
 * @OA\Tag(
 *     name="Users",
 *     description="API Endpoints for managing users"
 * )
 */
class UserController extends Controller
{


    public function registerUser (UserSignupRequest $request)
    {
        $referralCode = $request->input('referral_code');

        // Register the Customer
        $data = User::create([
            'firstname' => $request->firstname,
            'lastname' => $request->lastname,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'referral_code' => substr(str_shuffle('0123456789'), 0, 4)
        ]);

        // Create a wallet for the user
        $wallet = Wallet::create([
            'user_id' => $data->id
        ]);

        $referral_bonus = config('app.referral_bonus');

        // If a referral code is provided, validate it and update the referrer's wallet
        if ($referralCode) {
            $referrer = User::where('referral_code', $referralCode)->first();
            if ($referrer) {
                // Update the referrer's wallet
                $referrerWallet = Wallet::where('user_id', $referrer->id)->first();
                $referrerWallet->update([
                // Update the referrer's wallet with a bonus
                    'balance' => $referrerWallet->balance + $referral_bonus
                ]);

                // Update the user's referrer_id
                $data->update([
                    'referrer_id' => $referrer->id
                ]);
            }
        }

        // Generate OTP and save
        $otp = rand(1000, 9999); // Generate a 4-digit OTP

        User_otp::create([
            'otp' => $otp,
            'email' => $data->email,
        ]);


        // Send OTP via email
        Mail::to($data->email)->send(new UserRegisteredOtp($otp, $data->firstname));

        $token = $data->createToken('User _signUp')->plainTextToken;

        // Return success response
        return response()->json(['message' => 'An OTP has been sent to your email address. It expires after 15 minutes.', 'token' => $token, 'data' => $data], 201);
    }

    public function validateUserRegisterOTP(RegisterOTPRequest $request)
    {
        $otp = $request->otp;
        $email = $request->email;

        $UserData = User::where('email', $email)->first();
        $Userotp = User_otp::where('email', $email)->first();
        if (!$Userotp) {
            return response()->json(['success' => false, 'message' => 'No customer record found'], 404);
        }

        $otpRecord = User_otp::where('otp', $otp)->where('email', $email)->where('created_at', '>=', now()->subMinutes(50)) // Only consider OTPs created in the last 15 minutes
            ->first();

        if ($otpRecord) {
            // Update email_verified_at field
            $UserData->update([
                'email_verified_at' => now(),
            ]);

            // Send notification via email
            Mail::to($email)->send(new UserRegistered($UserData));

            $otpRecord->delete();

            $token = $UserData->createToken('User_signUp')->plainTextToken;
            return response()->json(['success' => true, 'message' => 'OTP validated successfully and registration Complete', 'token' => $token], 201);
        } else {
            return response()->json(['success' => false, 'message' => 'Invalid OTP or OTP has expired'], 400);
        }
    }
    public function User_login(UserLoginRequest $request)
    {
        // Retrieve customer data from the request
        $email = $request->email;
        $password = $request->password;

        // Check if the customer exists
        $user = User::where('email', $email)->first();

        if (!$user) {
            return response()->json(['success' => false, 'message' => 'Customer not found'], 404);
        }

        // Check if the password is correct
        if (!Hash::check($password, $user->password)) {
            return response()->json(['success' => false, 'message' => 'Invalid password'], 400);
        }

        // Generate a random OTP
        $otp = rand(1000, 9999);

        // Save the OTP to the database
        $data = [
            // 'otp' => $otp,
            'email' => $user->email,
            'user_id' => $user->id,
            'name' => $user->firstname,
            'lastname' => $user->lastname,
            'email' => $user->email,
        ];

        // Create a Sanctum token
        $token = $user->createToken('auth_token')->plainTextToken;

        // Send the OTP to the customer's email address
        Mail::to($user->email)->send(new UserLoginOtp($otp, $user->firstname));

        // Return a success response with the OTP and token
        return response()->json([
            'success' => true, 
            'message' => 'An OTP has been sent to your email address. OTP expires after 15 minutes.', 
            'data' => $data,
            'token' => $token
        ], 201);
    }
    public function validateUserLoginOTP(RegisterOTPRequest $request)
    {
        // Retrieve the OTP and email from the request
        $otp = $request->otp;
        $email = $request->email;

        // Check if the customer exists
        $user = User::where('email', $email)->first();

        if (!$user) {
            return response()->json(['success' => false, 'message' => 'Customer not found'], 404);
        }

        // Check if the OTP is valid
        $otpRecord = User_otp::where('otp', $otp)->where('email', $email)->where('created_at', '>=', now()->subMinutes(15)) // Only consider OTPs created in the last 15 minutes
            ->first();

        if (!$otpRecord) {
            return response()->json(['success' => false, 'message' => 'Invalid OTP or OTP has expired'], 400);
        }

        // Delete the OTP record
        $otpRecord->delete();

        // Generate a new token for the customer
        $token = $user->createToken('user_login')->plainTextToken;

        // Return a success response with the token
        return response()->json(['success' => true, 'message' => 'OTP validated successfully and login complete', 'token' => $token, 'data' => $otpRecord], 201);
    }

    public function fetchUserProfile($email)
{
    $cacheKey = 'user-profile-' . $email;
    $cacheTime = 60; // Cache for 1 hour

    $data = Cache::remember($cacheKey, $cacheTime, function () use ($email) {
        return User::where('email', $email)->with('wallet')->first();
    });

    if ($data) {
        return response()->json($data, 201);
    } else {
        return response()->json(['success' => false, 'message' => 'customer data not found'], 404);
    }
}

        public function editUserProfile($email, Request $request)
    {

        $userData = User::where('email', $email)->first();

        // Check if the customer exists
        if (!$userData) {
            return response()->json(['message' => 'Customer not found'], 404);
        }

        $userData->update([
            'firstname' => $request->firstname ?? $userData->firstname,
            'lastname' => $request->lastname ?? $userData->lastname,
            'phone' => $request->phone ?? $userData->phone,
        ]);

        if ($userData) {
            return response()->json(['success' => true, 'message' => 'Profile Updated Successfully', 'data' => $userData], 201);
        } else {
            return response()->json(['success' => false, 'message' => 'Problem Updating Profile'], 400);
        }
    }



     /**
     * @OA\Get(
     *     path="/users",
     *     summary="Get all users",
     *     tags={"Users"},
     *     @OA\Response(
     *         response=200,
     *         description="List of users retrieved successfully",
     *         @OA\JsonContent(
     *             type="array",
     *             @OA\Items(
     *                 @OA\Property(property="id", type="string", format="uuid"),
     *                 @OA\Property(property="name", type="string", example="John Doe"),
     *                 @OA\Property(property="email", type="string", format="email"),
     *                 @OA\Property(property="role", type="string"),
     *                 @OA\Property(property="email_verified_at", type="string", format="date-time", nullable=true),
     *                 @OA\Property(property="created_at", type="string", format="date-time"),
     *                 @OA\Property(property="updated_at", type="string", format="date-time")
     *             )
     *         )
     *     )
     * )
     */
    public function index()
    {
        return User::all();
    }

    /**
     * @OA\Put(
     *     path="/users/{id}",
     *     summary="Update a user",
     *     tags={"Users"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         required=true,
     *         description="UUID of the user",
     *         @OA\Schema(type="string", format="uuid")
     *     ),
     *     @OA\RequestBody(
     *         required=true,
     *         @OA\JsonContent(
     *             @OA\Property(property="name", type="string", example="John Doe"),
     *             @OA\Property(property="email", type="string", format="email"),
     *             @OA\Property(property="role", type="string")
     *         )
     *     ),
     *     @OA\Response(response=200, description="User updated successfully"),
     *     @OA\Response(response=404, description="User not found"),
     *     @OA\Response(response=422, description="Validation error")
     * )
     */
    public function update(Request $request, $id)
    {
        $user = User::findOrFail($id);
        $user->update($request->all());

        return response()->json(['message' => 'User updated successfully']);
    }

    /**
     * @OA\Patch(
     *     path="/users/{id}/toggle-status",
     *     summary="Toggle user active status",
     *     tags={"Users"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         required=true,
     *         description="UUID of the user",
     *         @OA\Schema(type="string", format="uuid")
     *     ),
     *     @OA\Response(response=200, description="User status updated successfully"),
     *     @OA\Response(response=404, description="User not found")
     * )
     */
    public function toggleStatus($id)
    {
        $user = User::findOrFail($id);
        $user->active = !$user->active;
        $user->save();

        return response()->json(['message' => 'User status updated successfully']);
    }

    /**
     * @OA\Delete(
     *     path="/users/{id}",
     *     summary="Delete a user",
     *     tags={"Users"},
     *     @OA\Parameter(
     *         name="id",
     *         in="path",
     *         required=true,
     *         description="UUID of the user",
     *         @OA\Schema(type="string", format="uuid")
     *     ),
     *     @OA\Response(response=200, description="User deleted successfully"),
     *     @OA\Response(response=404, description="User not found")
     * )
     */
    public function destroy($id)
    {
        $user = User::findOrFail($id);
        $user->delete();

        return response()->json(['message' => 'User deleted successfully']);
    }
}
