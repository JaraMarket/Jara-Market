<h3>Login OTP</h3>

<h4>Hello, <?php echo e($firstname); ?></h4>
<p>Your OTP for Login process is: <strong><?php echo e($otp); ?></strong></p>
<p>Please do not share this OTP with anyone.</p>

<p>Thanks</p>
<p><?php echo e(Config('app.name')); ?> Team. </p>
<?php /**PATH /Users/edidiong/Downloads/Jara-Market-edidiong/resources/views/emails/User_login_otp.blade.php ENDPATH**/ ?>