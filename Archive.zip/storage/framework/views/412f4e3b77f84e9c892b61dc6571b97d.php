<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <script src="https://unpkg.com/@tailwindcss/browser@4"></script>
    <title><?php echo e(config('app.name', 'Food Delivery Dashboard')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Scripts -->
    
</head>

<body class="font-sans antialiased">
    <div class="min-h-screen bg-gray-50">
        <div class="flex h-screen overflow-hidden">
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="flex flex-col flex-1 w-0 overflow-hidden">
                <?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <main class="relative flex-1 overflow-y-auto focus:outline-none">
                    <div class="py-6">
                        <div class="px-4 mx-auto max-w-7xl sm:px-6 md:px-8">
                            <h1 class="text-2xl font-semibold text-gray-900"><?php echo $__env->yieldContent('header'); ?></h1>
                        </div>
                        <div class="px-4 mx-auto max-w-7xl sm:px-6 md:px-8">
                            <?php echo $__env->yieldContent('content'); ?>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </div>
    <?php echo $__env->yieldContent('modals'); ?>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH /Users/edidiong/JaraMarket/resources/views/layouts/app.blade.php ENDPATH**/ ?>