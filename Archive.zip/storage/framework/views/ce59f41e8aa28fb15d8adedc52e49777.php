
<h3>Customer Registered Successfully</h3>

<p>Dear <?php echo e($UserData->firstname); ?>,</p>

<p>Thank you for registering with us. Your account has been created successfully.</p>

<p>Please keep your password Safe.</p>

Best regards,
<p><?php echo e(config('app.name')); ?></p>
<?php /**PATH /Users/edidiong/Downloads/Jara-Market-edidiong/resources/views/emails/User_registered.blade.php ENDPATH**/ ?>