<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8">
    <div class="max-w-4xl mx-auto">
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold text-gray-800">Edit Product</h1>
                <a href="<?php echo e(route('products.index')); ?>" class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-md transition duration-300">
                    Back to Products
                </a>
            </div>

            <form action="<?php echo e(route('products.update', $product)); ?>" method="POST" enctype="multipart/form-data" class="space-y-6">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <!-- Product Name -->
                    <div class="col-span-2">
                        <label for="name" class="block text-sm font-medium text-gray-700">Product Name</label>
                        <input type="text" name="name" id="name" value="<?php echo e(old('name', $product->name)); ?>"
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Description -->
                    <div class="col-span-2">
                        <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
                        <textarea name="description" id="description" rows="3"
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('description', $product->description)); ?></textarea>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Price -->
                    <div>
                        <label for="price" class="block text-sm font-medium text-gray-700">Price</label>
                        <div class="mt-1 relative rounded-md shadow-sm">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <span class="text-gray-500 sm:text-sm">$</span>
                            </div>
                            <input type="number" name="price" id="price" step="0.01" value="<?php echo e(old('price', $product->price)); ?>"
                                class="pl-7 mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        </div>
                        <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Discount Price -->
                    <div>
                        <label for="discount_price" class="block text-sm font-medium text-gray-700">Discount Price (Optional)</label>
                        <div class="mt-1 relative rounded-md shadow-sm">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <span class="text-gray-500 sm:text-sm">$</span>
                            </div>
                            <input type="number" name="discount_price" id="discount_price" step="0.01" value="<?php echo e(old('discount_price', $product->discount_price)); ?>"
                                class="pl-7 mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 <?php $__errorArgs = ['discount_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        </div>
                        <?php $__errorArgs = ['discount_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Stock -->
                    <div>
                        <label for="stock" class="block text-sm font-medium text-gray-700">Stock</label>
                        <input type="number" name="stock" id="stock" value="<?php echo e(old('stock', $product->stock)); ?>"
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 <?php $__errorArgs = ['stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['stock'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Rating -->
                    <div>
                        <label for="rating" class="block text-sm font-medium text-gray-700">Rating</label>
                        <input type="number" name="rating" id="rating" min="0" max="5" step="0.1" value="<?php echo e(old('rating', $product->rating)); ?>"
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Categories -->
                    <div class="col-span-2">
                        <label class="block text-sm font-medium text-gray-700">Categories</label>
                        <div class="mt-2 space-y-2">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="flex items-center">
                                    <input type="checkbox" name="categories[]" value="<?php echo e($category->id); ?>" id="category_<?php echo e($category->id); ?>"
                                        <?php echo e(in_array($category->id, old('categories', $product->categories->pluck('id')->toArray())) ? 'checked' : ''); ?>

                                        class="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded">
                                    <label for="category_<?php echo e($category->id); ?>" class="ml-2 block text-sm text-gray-900">
                                        <?php echo e($category->name); ?>

                                    </label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php $__errorArgs = ['categories'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Ingredients -->
                    <div class="sm:col-span-6">
                        <label for="ingredients" class="block text-sm font-medium text-gray-700">
                            Ingredients <span class="text-red-500">*</span>
                        </label>
                        <div class="mt-1 space-y-4" id="ingredients-container">
                            <?php $__currentLoopData = $product->ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="ingredient-item flex gap-4">
                                    <div class="flex-1">
                                        <input type="text" name="ingredients[<?php echo e($index); ?>][name]" value="<?php echo e($ingredient->name); ?>" class="shadow-sm focus:ring-green-500 focus:border-green-500 block w-full sm:text-sm border-gray-300 rounded-md" readonly>
                                        <input type="hidden" name="ingredients[<?php echo e($index); ?>][ingredient_id]" value="<?php echo e($ingredient->id); ?>">
                                    </div>
                                    <div class="w-32">
                                        <input type="number" name="ingredients[<?php echo e($index); ?>][quantity]" step="0.01" min="0" placeholder="Quantity" value="<?php echo e($ingredient->pivot->quantity); ?>" class="shadow-sm focus:ring-green-500 focus:border-green-500 block w-full sm:text-sm border-gray-300 rounded-md">
                                    </div>
                                    <div class="w-32">
                                        <select name="ingredients[<?php echo e($index); ?>][unit]" class="shadow-sm focus:ring-green-500 focus:border-green-500 block w-full sm:text-sm border-gray-300 rounded-md">
                                            <option value="piece" <?php echo e($ingredient->pivot->unit == 'piece' ? 'selected' : ''); ?>>Piece</option>
                                            <option value="kg" <?php echo e($ingredient->pivot->unit == 'kg' ? 'selected' : ''); ?>>Kilogram</option>
                                            <option value="g" <?php echo e($ingredient->pivot->unit == 'g' ? 'selected' : ''); ?>>Gram</option>
                                            <option value="l" <?php echo e($ingredient->pivot->unit == 'l' ? 'selected' : ''); ?>>Liter</option>
                                            <option value="ml" <?php echo e($ingredient->pivot->unit == 'ml' ? 'selected' : ''); ?>>Milliliter</option>
                                            <option value="cup" <?php echo e($ingredient->pivot->unit == 'cup' ? 'selected' : ''); ?>>Cup</option>
                                            <option value="tbsp" <?php echo e($ingredient->pivot->unit == 'tbsp' ? 'selected' : ''); ?>>Tablespoon</option>
                                            <option value="tsp" <?php echo e($ingredient->pivot->unit == 'tsp' ? 'selected' : ''); ?>>Teaspoon</option>
                                        </select>
                                    </div>
                                    <div class="flex items-center">
                                        <button type="button" onclick="this.parentElement.parentElement.remove()" class="text-red-600 hover:text-red-800">
                                            <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                            </svg>
                                        </button>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="mt-2">
                            <button type="button" onclick="showAddIngredientModal()" class="inline-flex items-center px-3 py-2 border border-transparent text-sm leading-4 font-medium rounded-md text-green-700 bg-green-100 hover:bg-green-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                                <svg class="-ml-0.5 mr-2 h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                                </svg>
                                Add Ingredient
                            </button>
                        </div>
                        <?php $__errorArgs = ['ingredients'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Preparation Steps -->
                    <div class="col-span-2">
                        <label for="preparation_steps" class="block text-sm font-medium text-gray-700">Preparation Steps</label>
                        <textarea name="preparation_steps" id="preparation_steps" rows="3"
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 <?php $__errorArgs = ['preparation_steps'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('preparation_steps', $product->preparation_steps)); ?></textarea>
                        <?php $__errorArgs = ['preparation_steps'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <!-- Add Ingredient Modal -->
                <div id="addIngredientModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000;">
                    <div style="position: relative; background: white; width: 400px; margin: 100px auto; padding: 20px; border-radius: 5px;">
                        <h3 style="margin-bottom: 20px;">Add New Ingredient</h3>
                        <div style="margin-bottom: 15px;">
                            <label>Ingredient Name</label>
                            <select id="new_ingredient_id" style="width: 100%; padding: 8px; margin-top: 5px;">
                                <option value="">Select Ingredient</option>
                                <?php $__currentLoopData = \App\Models\Ingredient::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($ingredient->id); ?>"><?php echo e($ingredient->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div style="margin-bottom: 15px;">
                            <label>Quantity</label>
                            <input type="number" id="new_ingredient_quantity" step="0.01" min="0" style="width: 100%; padding: 8px; margin-top: 5px;">
                        </div>
                        <div style="margin-bottom: 15px;">
                            <label>Unit</label>
                            <select id="new_ingredient_unit" style="width: 100%; padding: 8px; margin-top: 5px;">
                                <option value="piece">Piece</option>
                                <option value="kg">Kilogram</option>
                                <option value="g">Gram</option>
                                <option value="l">Liter</option>
                                <option value="ml">Milliliter</option>
                                <option value="cup">Cup</option>
                                <option value="tbsp">Tablespoon</option>
                                <option value="tsp">Teaspoon</option>
                            </select>
                        </div>
                        <div style="text-align: right;">
                            <button onclick="cancelNewIngredient()" style="padding: 8px 15px; margin-right: 10px; background: #ccc;">Cancel</button>
                            <button onclick="saveNewIngredient()" style="padding: 8px 15px; background: #4CAF50; color: white;">Save</button>
                        </div>
                    </div>
                </div>

                <div class="flex justify-end space-x-4">
                    <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md transition duration-300">
                        Update Product
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function showAddIngredientModal() {
    document.getElementById('addIngredientModal').style.display = 'block';
}

function cancelNewIngredient() {
    document.getElementById('addIngredientModal').style.display = 'none';
    document.getElementById('new_ingredient_id').value = '';
    document.getElementById('new_ingredient_quantity').value = '';
}

function saveNewIngredient() {
    const ingredientId = document.getElementById('new_ingredient_id').value;
    const ingredientName = document.getElementById('new_ingredient_id').options[document.getElementById('new_ingredient_id').selectedIndex].text;
    const quantity = document.getElementById('new_ingredient_quantity').value;
    const unit = document.getElementById('new_ingredient_unit').value;
    
    if (ingredientId && quantity) {
        const container = document.getElementById('ingredients-container');
        const count = container.children.length;
        
        const newRow = document.createElement('div');
        newRow.className = 'ingredient-item flex gap-4 mt-4';
        newRow.innerHTML = `
            <div class="flex-1">
                <input type="text" name="ingredients[${count}][name]" value="${ingredientName}" class="shadow-sm focus:ring-green-500 focus:border-green-500 block w-full sm:text-sm border-gray-300 rounded-md" readonly>
                <input type="hidden" name="ingredients[${count}][ingredient_id]" value="${ingredientId}">
            </div>
            <div class="w-32">
                <input type="number" name="ingredients[${count}][quantity]" value="${quantity}" step="0.01" min="0" class="shadow-sm focus:ring-green-500 focus:border-green-500 block w-full sm:text-sm border-gray-300 rounded-md">
            </div>
            <div class="w-32">
                <select name="ingredients[${count}][unit]" class="shadow-sm focus:ring-green-500 focus:border-green-500 block w-full sm:text-sm border-gray-300 rounded-md">
                    <option value="piece" ${unit === 'piece' ? 'selected' : ''}>Piece</option>
                    <option value="kg" ${unit === 'kg' ? 'selected' : ''}>Kilogram</option>
                    <option value="g" ${unit === 'g' ? 'selected' : ''}>Gram</option>
                    <option value="l" ${unit === 'l' ? 'selected' : ''}>Liter</option>
                    <option value="ml" ${unit === 'ml' ? 'selected' : ''}>Milliliter</option>
                    <option value="cup" ${unit === 'cup' ? 'selected' : ''}>Cup</option>
                    <option value="tbsp" ${unit === 'tbsp' ? 'selected' : ''}>Tablespoon</option>
                    <option value="tsp" ${unit === 'tsp' ? 'selected' : ''}>Teaspoon</option>
                </select>
            </div>
            <div class="flex items-center">
                <button type="button" onclick="this.parentElement.parentElement.remove()" class="text-red-600 hover:text-red-800">
                    <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                </button>
            </div>
        `;
        
        container.appendChild(newRow);
        cancelNewIngredient();
    }
}
</script>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/edidiong/Downloads/Jara-Market-edidiong/resources/views/products/edit.blade.php ENDPATH**/ ?>