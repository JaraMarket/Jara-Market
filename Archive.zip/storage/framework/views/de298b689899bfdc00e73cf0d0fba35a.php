<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8">
    <div class="max-w-4xl mx-auto">
        <div class="bg-white rounded-lg shadow-md p-6">
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-bold text-gray-800">Create New Order</h1>
                <a href="<?php echo e(route('orders.index')); ?>" class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-md transition duration-300">
                    Back to Orders
                </a>
            </div>

            <?php if($errors->any()): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form action="<?php echo e(route('orders.store')); ?>" method="POST" class="space-y-6">
                <?php echo csrf_field(); ?>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <!-- User Selection -->
                    <div class="col-span-2">
                        <label for="user_id" class="block text-sm font-medium text-gray-700">User</label>
                        <select name="user_id" id="user_id" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500" required>
                            <option value="">Select User</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>" <?php echo e(old('user_id') == $user->id ? 'selected' : ''); ?>><?php echo e($user->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <!-- Meal Prep Instructions -->
                    <div class="col-span-2">
                        <label for="meal_prep" class="block text-sm font-medium text-gray-700">Meal Preparation Instructions</label>
                        <textarea name="meal_prep" id="meal_prep" rows="4" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500" placeholder="Enter any specific instructions for meal preparation (optional)"><?php echo e(old('meal_prep')); ?></textarea>
                    </div>

                    <!-- Order Items -->
                    <div class="col-span-2">
                        <label class="block text-sm font-medium text-gray-700">Order Items</label>
                        <div class="mt-2 space-y-4">
                            <?php for($i = 0; $i < 3; $i++): ?>
                                <div class="order-item flex gap-4">
                                    <div class="flex-1">
                                        <select name="items[<?php echo e($i); ?>][product_id]" class="block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500" <?php echo e($i == 0 ? 'required' : ''); ?>>
                                            <option value="">Select Product</option>
                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($product->id); ?>" <?php echo e(old("items.$i.product_id") == $product->id ? 'selected' : ''); ?>><?php echo e($product->name); ?> - ₦<?php echo e(number_format($product->price, 2)); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="w-32">
                                        <input type="number" name="items[<?php echo e($i); ?>][quantity]" min="1" value="<?php echo e(old("items.$i.quantity", 1)); ?>" class="block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500" <?php echo e($i == 0 ? 'required' : ''); ?>>
                                    </div>
                                </div>
                            <?php endfor; ?>
                        </div>
                    </div>

                    <!-- Total Amount -->
                    <div class="col-span-2">
                        <label for="total" class="block text-sm font-medium text-gray-700">Total Amount</label>
                        <div class="mt-1">
                            <input type="number" step="0.01" name="total" id="total" class="block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500" required value="<?php echo e(old('total')); ?>">
                        </div>
                    </div>
                </div>

                <div class="flex justify-end space-x-4">
                    <button type="submit" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md transition duration-300">
                        Create Order
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/edidiong/Downloads/Jara-Market-edidiong/resources/views/orders/create.blade.php ENDPATH**/ ?>